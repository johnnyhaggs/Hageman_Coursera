Author: John Hageman
Course: Embedded System Engineering Coursera Course 1
Assignment: Module 1 Assessment

Statistics program for analyzing arrays of char data items.
Reports minimum, maximum, mean, and median of the dataset.
